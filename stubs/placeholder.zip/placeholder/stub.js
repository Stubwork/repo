const comments = require('./data/comments.json');
const albums = require('./data/albums.json');
const photos = require('./data/photos.json');
const posts = require('./data/posts.json');
const todos = require('./data/todos.json');
const users = require('./data/users.json');


module.exports = {
    'GET /api/comments': comments,
    'GET /api/albums': albums,
    'GET /api/photos': photos,
    'GET /api/posts': posts,
    'GET /api/todos': todos,
    'GET /api/users': users,
}